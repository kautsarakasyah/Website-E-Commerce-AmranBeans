<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" href="{{ asset('frontn/css/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{ asset('frontn/css/boxicons.min.css')}}" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link rel="stylesheet" href="{{ asset('frontn/css/style.css')}}" /> 
    

    <title>AmranBeans</title>
  </head>

  <body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="70">
     <!-- NAVBAR -->
     <nav class="navbar navbar-expand-lg py-3 sticky-top navbar-dark bg-dark">
      <div class="container">
      <a class="navbar-brand" href="{{ route('beranda') }}">
          <img class="logo" src="frontn/img/logo-dark.jpg" alt="" />
    </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="{{ route('beranda') }}"><i class=""></i>Beranda</a>
        </li>
        <li class="nav-item">
              <a class="nav-link" href="{{ route('hproduk') }}">
              <i class=""></i>Produk</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('keranjang') }}">
              <i class="fas fa-fw fa-cart-arrow-down"></i>Keranjang</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('riwayat') }}">
              <i class=""></i>Transaksi</a>
            </li>
            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">

            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa-solid fa-user"></i>
            <span class="mr-2 d-none d-lg-inline text-gray-600 small">{{ Auth::user()->name }}</span></a>
            <!-- Dropdown - User Information -->
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
          </ul>
        </div>
      </div>
    </nav>
    <!-- //NAVBAR -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-center mb-4">
                        <h1 class="h3 mb-0 mt-4 text-gray-800">Invoicemu</h1>
                    </div>


                    <!-- Kategori Card Example -->
                    <!-- <div class="card shadow mb-4"> -->
                        <div class="card shadow mb-3" style="max-width: 75%;">
                        <div class="row g-0">
                            <div class="col-md-8">
                            <div class="card-body">
                            <div class="ms-3">
                                <form action="{{ route('kirim') }}" method="POST" enctype="multipart/form-data">
                                    {{ csrf_field()}}
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-success btn-submit">Pesan</button>
                                    </div>
                                </form>
                            </div>
                            <hr>
                            <form>
                                <div class="form-group">
                                    <label class="form-label">Nama Produk :</label>
                                    @foreach($dtnama_produk as $np)
                                        <div>
                                        {{ $loop->iteration }}. {{ $np }} x ({{ $dtqty_produk[$loop->index] }}) = Rp. 
                                            @foreach($dtharga_produk as $hp)
                                                @if($loop->index == $loop->parent->index)
                                                    {{ $hp }} 
                                                @endif
                                            @endforeach
                                        </div>
                                    @endforeach
                                </div>
                            </form>
                            <form>
                                <div class="form-group">
                                    <label class="form-label">Biaya Ongkir :</label>
                                    <div>
                                    {{ $kd_ongkir }} - Rp. {{ $harga_ongkir }}
                                    </div>
                                </div>
                            </form>
                            <form>
                                <fieldset disabled>
                                <div class="form-group">
                                    <label class="form-label">Total Bayar :</label>
                                    <div>
                                    Rp. {{ $total }}
                                    </div>
                                </div>
                            </form>
                            <div class="produk-list">
                            <div class="card text-center" style="width: 18rem; margin-right: 10px;">
                                <div class="card-body">
                                    <div class="sablon">
                                        <img src="frontn/img/dana.png" class="d-block w-100" alt="...">
                                      </div>
                                  <h5 class="card-title">DANA</h5>
                                </div>
                              </div>
                            <div class="card text-center" style="width: 18rem; margin-right: 10px;">
                                <div class="card-body">
                                    <div class="sablon">
                                        <img src="frontn/img/ovo.png" class="d-block w-100" alt="...">
                                      </div>
                                  <h5 class="card-title">OVO</h5>
                                </div>
                              </div>
                              <div class="card text-center" style="width: 18rem; margin-right: 10px;">
                                <div class="card-body">
                                    <div class="sablon">
                                    <div class="p-3 mb-2 bg-white text-dark">METODE PEMBAYARAN!!!</div> 
                                    <div class="p-3 mb-2 bg-success text-white">GoPay : (0821-149-1217)</div> 
                                    <div class="p-3 mb-2 bg-warning text-white">ShopeePay : (0821-149-1217)</div>
                                    <div class="p-3 mb-2 bg-info text-white">DANA : (0821-149-1217)</div>
                                    <div class="p-3 mb-2 bg-primary text-white">BCA A/N Kautsar Baihaqi Akasyah : 13119237</div>
                                  </div>
                                </div>
                              </div>
                        </div>
                            <div class="card-footer text-white ">
                            <div class="p-3 mb-4 bg-danger text-white">NOTED !!! Gunakan tamplate chat berikut untuk upload bukti Pembayaranmu.</div>
                            <p class="text-dark">Tanggal Bayar :</p>
                            <p class="text-dark">Nama          :</p>
                            <p class="text-dark">No.Telepon    :</p>
                            <p class="text-dark">Jumlah Bayar  :</p>
                            <p class="text-danger">UPLOAD BUKTI PEMBAYARANMU DI LIVECHAT !!!</p>
                            </div>
                            </div>
    

                            
                        </div>
                        </div>

                        
                    <!-- </div> -->

                </div>
                <!-- /.container-fluid -->

           
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Yakin ingin keluar ?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Klik logout untuk keluar</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="{{ route('logout') }}">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <footer>
      <div class="footer-top">
        <div class="container">
          <div class="row gy-4">
            <div class="col-lg-4  ">
              <a href href="#home"><img class="logo" src="frontn/img/logo-dark.jpg" alt="" ></a>
            </div>
            <div class="col-lg-4">
              <h5 class="text-white">AmranBeans</h5>
              <ul class="list-unstyled">
                <li><a href="#home">Beranda</a></li>
                <li><a href="#about">Tentang Kami</a></li>
                <li><a href="#produk">Produk Kami</a></li>
              </ul>
            </div>
            <div class="col-lg-4">
              <h5 class="text-white">Kontak Kami</h5>
              <ul class="list-unstyled">
                <li><a href="https://goo.gl/maps/ynG1ccbjBxks8eGq7">ALAMAT</a></li>
                <li>EMAIL : amranbeans@gmail.com</li>
                <li><a href="https://wa.me/082114491217">HUBUNGI KAMI</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-bottom py-3">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <p class="mb-0">© 2022 copyright all right reserved | Designed with <i class="bx bx-heart text-danger"></i> by<a href="https://www.youtube.com/channel/UCYMEEnLzGGGIpQQ3Nu_sBsQ" class="text-white">AmranBeans</a></p>
            </div>
            <div class="col-md-6">
              <div class="social-icons">
                <a href="https://www.facebook.com/profile.php?viewas=100000686899395&id=100082078694523"><i class="bx bxl-facebook"></i></a>
                <a href="https://twitter.com/AmranBeans"><i class="bx bxl-twitter"></i></a>
                <a href="https://www.instagram.com/amranbeans/"><i class="bx bxl-instagram-alt"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>

        <!-- Start of txt.me widget code -->
  <script src="https://v3.txt.me/livechat/js/wrapper/5d08a2b6-e08a-48cd-94bb-1c65eae906eb" async></script>
  <noscript><a href="https://txt.me/reviews/5d08a2b6-e08a-48cd-94bb-1c65eae906eb" rel="nofollow">Rate AmranBeans customer support</a>, powered by <a href="https://txt.me" rel="noopener nofollow" target="_blank">txt.me</a></noscript>
  <!-- End of txt.me widget code -->

    <!-- Bootstrap core JavaScript-->
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="assets/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="assets/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="assets/vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="assets/js/demo/chart-area-demo.js"></script>
    <script src="assets/js/demo/chart-pie-demo.js"></script>

</body>

</html>