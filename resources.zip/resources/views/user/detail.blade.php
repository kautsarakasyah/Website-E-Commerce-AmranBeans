<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" href="{{ asset('frontn/css/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{ asset('frontn/css/boxicons.min.css')}}" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link rel="stylesheet" href="{{ asset('frontn/css/style.css')}}" />

    <title>Detail - {{ $detail->nama_produk }}</title>
</head>

  <body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="70">
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg py-3 sticky-top navbar-dark bg-dark">
      <div class="container">
      <a class="navbar-brand" href="{{ route('beranda') }}">
          <img class="logo" src="{{asset ('frontn/img/logo-dark.jpg')}}" alt="" />
    </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="{{ route('beranda') }}"><i class=""></i>Beranda</a>
        </li>
        <li class="nav-item">
              <a class="nav-link" href="{{ route('hproduk') }}">
              <i class=""></i>Produk</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('keranjang') }}">
              <i class="fas fa-fw fa-cart-arrow-down"></i>Keranjang</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('riwayat') }}">
              <i class=""></i>Transaksi</a>
            </li>
              <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">

              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fa-solid fa-user"></i>
              <span class="mr-2 d-none d-lg-inline text-gray-600 small">{{ Auth::user()->name }}</span></a>

              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
              <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                      Logout
                                  </a>
                              </div>
          </ul>
        </div>
      </div>
    </nav>
    <!-- //NAVBAR -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-center mb-4 ">
                        <h1 class="h3 mb-0 mt-4 text-gray-800">Detail Produk</h1>
                    </div>


                    <!-- Kategori Card Example -->
                    <div class="card shadow-sm p-3 bg-body rounded" style="width: 18rem;">
                    <img class="card-img-top" src="{{ asset('images/produk/'. $detail->gambar ) }}" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">{{ $detail->nama_produk }}</h5>
                        @if($detail->kuantitas >= 1)
                            <p class="text-success">Tersedia</p>
                            <p class="card-text">Sisa barang : {{ $detail->kuantitas }}</p>
                        @else
                            <p class="text-danger">Habis</p>
                        @endif
                        <p class="text-primary">Harga : Rp {{ $detail->harga }}</p>
                        <p class="card-text">{!! $detail->deskripsi !!}</p>
                    </div>
                    <form action="{{ route('tambah-keranjang',$detail->id) }}" method="POST">
                        {{ csrf_field()}}
                        @if($detail->kuantitas >= 1)
                        <div class="card-footer bg-white">
                            <input type="number" min="1" max="{{$detail->kuantitas}}" id="qty" name="qty" placeholder="Masukkan Jumlah Barang yang Di Inginkan!!" class="form-control @error('qty') is-invalid @enderror"  required>
                            <button type="submit" class="btn btn-info px-3 mt-2">
                                <i class="fas fa-cart-arrow-down"></i>
                            </button>
                        </div>
                        @else
                        <div class="card-footer bg-white">
                            <button type="submit" class="btn btn-success px-3" disabled>
                                <i class="fas fa-cart-arrow-down"></i>
                            </button>
                        </div>
                        @endif
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

       <!-- Logout Modal-->
       <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Yakin ingin keluar ?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Klik logout untuk keluar</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="{{ route('logout') }}">Logout</a>
                </div>
            </div>
        </div>
    </div>
<!-- Logout Modal-->
    

<footer>
      <div class="footer-top">
        <div class="container">
          <div class="row gy-4">
            <div class="col-lg-4  ">
              <a href href="#home"><img class="logo" src="{{asset ('frontn/img/logo-dark.jpg')}}" alt="" ></a>
            </div>
            <div class="col-lg-4">
              <h5 class="text-white">AmranBeans</h5>
              <ul class="list-unstyled">
                <li><a href="#home">Beranda</a></li>
                <li><a href="#about">Tentang Kami</a></li>
                <li><a href="#produk">Produk Kami</a></li>
              </ul>
            </div>
            <div class="col-lg-4">
              <h5 class="text-white">Kontak Kami</h5>
              <ul class="list-unstyled">
                <li><a href="https://goo.gl/maps/ynG1ccbjBxks8eGq7">ALAMAT</a></li>
                <li>EMAIL : amranbeans@gmail.com</li>
                <li><a href="https://wa.me/082114491217">HUBUNGI KAMI</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-bottom py-3">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <p class="mb-0">© 2022 copyright all right reserved | Designed with <i class="bx bx-heart text-danger"></i> by<a href="https://www.youtube.com/channel/UCYMEEnLzGGGIpQQ3Nu_sBsQ" class="text-white">AmranBeans</a></p>
            </div>
            <div class="col-md-6">
              <div class="social-icons">
                <a href="https://www.facebook.com/profile.php?viewas=100000686899395&id=100082078694523"><i class="bx bxl-facebook"></i></a>
                <a href="https://twitter.com/AmranBeans"><i class="bx bxl-twitter"></i></a>
                <a href="https://www.instagram.com/amranbeans/"><i class="bx bxl-instagram-alt"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>

  <!-- Start of txt.me widget code -->
  <script src="https://v3.txt.me/livechat/js/wrapper/5d08a2b6-e08a-48cd-94bb-1c65eae906eb" async></script>
  <noscript><a href="https://txt.me/reviews/5d08a2b6-e08a-48cd-94bb-1c65eae906eb" rel="nofollow">Rate AmranBeans customer support</a>, powered by <a href="https://txt.me" rel="noopener nofollow" target="_blank">txt.me</a></noscript>
  <!-- End of txt.me widget code -->

    <script src="frontn/js/bootstrap.bundle.min.js"></script>

     <!-- Bootstrap core JavaScript-->
     <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="assets/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="assets/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="assets/vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="assets/js/demo/chart-area-demo.js"></script>
    <script src="assets/js/demo/chart-pie-demo.js"></script>
  </body>
</html>
