<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Middleware\Auth;
use Illuminate\Support\Str;
use App\Models\User;
use App\Models\Produk;
use App\Models\Kategori;
use App\Models\Keranjang;
use App\Models\Transaksi;
use App\Models\Ongkir;

class HprodukController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = User::get()->all();
        $kategori = Kategori::get()->all();
        $dtProduk = Produk::orderBy('id', 'desc')->paginate(5);
        return view('hproduk', compact('dtProduk', 'user', 'kategori'));
    }
}