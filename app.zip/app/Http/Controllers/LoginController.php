<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
/** Tambahan **/
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Support\Facades\Session;
/** Tambahan **/
class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::check()){
            return redirect()->back();
        } else{
            return view('login');
        }
    }

    public function postlogin(request $request)
    {
        /** Tambahan **/
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|current_password',
            'password' => 'required|',
          ]);

          $email = $request->email;
          $password = $request->password;

          $data = User::where('email',$email)->first();
        if($data){ //apakah email tersebut ada atau tidak
            if(Hash::check($password,$data->password)){
                Session::put('email',$data->email);
                Session::put('login',TRUE);

            }
            else{
                return back()->with('fail', 'Email atau Password anda Salah');
            }
        }
        else{
            return back()->with('fail', 'Email atau Password anda Salah');
        }
        /** Tambahan **/

        if (Auth::attempt($request->only('email', 'password'))) {
            if(Auth::user()->role == 'adm')
            {
                return redirect('admin');
            }
            elseif(Auth::user()->role == 'usr')
            {
                return redirect('beranda');
            }
        }
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/');
    }
}
