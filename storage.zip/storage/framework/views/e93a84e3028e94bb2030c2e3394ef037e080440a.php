<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <link rel="stylesheet" href="<?php echo e(asset('frontn/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontn/css/boxicons.min.css')); ?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('frontn/css/style.css')); ?>" />

    <title>AmranBeans</title>
  </head>

  <body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="70">
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg py-3 sticky-top navbar-dark bg-dark">
      <div class="container">
      <a class="navbar-brand" href="#home">
          <img class="logo" src="frontn/img/logo-dark.jpg" alt="" />
    </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="#home">Beranda</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#about">Tentang Kami</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#project">Galeri</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#produk">Produk</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- //NAVBAR -->

    <!-- HERO -->
    <div class="hero vh-100 d-flex align-items-center" id="home">
      <div class="container">
        <div class="row">
          <div class="col-lg-7 mx-auto text-center">
            <h1 class="display-4 text-white">Rasakan Kenikmatan Kopi Pagar Alam</h1>
            <p class="text-white my-3">Ingin nikmati secangkir kopi robusta berkualitas tinggi? Sekarang bisa, langsung tekan tombol Beli Sekarang di bawah.</p>
            <a href="#produk" class="btn me-2 btn-info">Beli Sekarang</a>
            <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-light">Register</a>
          </div>
        </div>
      </div>
    </div>
    <!-- //HERO -->
    
    <!-- ABOUT -->
    <section class="row w-100 py-0 bg-light" id="about">
      <div class="col-lg-6 col-img"></div>
      <div class="col-lg-6 py-5">
        <div class="container">
          <div class="row">
            <div class="col-md-10 offset-md-1">
            <h6 class="text-primary mt-5">Seputar Kami</h6>
              <h1>Selamat Datang di AmranBeans </h1>
              <p>AmranBeans merupakah situs jual beli biji kopi robusta khas Pagar Alam. </p>

              <div class="feature d-flex mt-5">
                <div class="iconbox me-3">
                
                <i class="bx bxs-check-shield"></i>
              </div>
              
                <div>
                  <h5>TERJAMIN AMAN</h5>
                  <p>Jangan ragu untuk melakukan pemesanan di AmranBeans, karna toko AmranBeans di jaman aman.</p>
                </div>
              </div>
              <div class="feature d-flex">
                <div class="iconbox me-3">
                <i class="bx bxs-heart"></i>
                </div>
                <div>
                  <h5>KUALITAS TERBAIK</h5>
                  <p>Produk Kopi yang di hasilkan oleh AmranBeans merupakan biji kopi pilihan dari pohon kopi terbaik </p>
                </div>
              </div>
              <div class="feature d-flex">
                <div class="iconbox me-3">
                <i class="bx bxs-user-circle"></i>
                </div>
                <div>
                  <h5>CUSTOMER SERVICE</h5>
                  <p>08.00 - 21.00 WIB Live Chat. </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- ABOUT -->

    <!-- GALERI -->
    <section id="project">
      <div class="container-fluid">
        <div class="row mb-5">
          <div class="col-md-8 mx-auto text-center">
            <h6 class="text-primary">GALERI</h6>
            <h1>Galeri Seputar Kami</h1>
            <p>Tahapan proses pengolahan biji kopi Amran Beans</p>
          </div>
        </div>
        <div class="row g-3">
          <div class="col-lg-4 col-sm-6">
            <div class="project">
              <img src="frontn/img/galeri1.jpeg" alt="" height="400px" width="100px"/>
              <div class="overlay">
                <div>
                  <h4 class="text-white">Gunung Dempo</h4>
                  <h6 class="text-white">Gunung Dempo (3'159 mdpl) terletak di perbatasan provinsi Sumatra Selatan dan provinsi Bengkulu tepatnya di kota dingin penghasil kopi robusta yaitu Kota Pagaralam.</h6>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-sm-6">
            <div class="project">
              <img src="frontn/img/galeri.jpeg" alt="" height="400px" width="100px" />
              <div class="overlay">
                <div>
                  <h4 class="text-white">Pohon Kopi</h4>
                  <h6 class="text-white">Pohon Kopi penghasil biji kopi Robusta khas Pagar Alam, pohon kopi ini lah yang buahnya nanti akan di petik dan di sortir untuk pemrosesan Biji Kopi selanjutnya</h6>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-sm-6">
            <div class="project">
              <img src="frontn/img/galeri3.jpeg" alt="" height="400px" width="100px"/>
              <div class="overlay">
                <div>
                  <h4 class="text-white">Natural Dry Process</h4>
                  <h6 class="text-white">Buah kopi di keringkan dan di jemur di bawah matahari langsung, buah kopi yang ditebar dan dijemur tidak dikupas, melainkan dijemur beserta kulit dan daging buahnya.</h6>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-sm-6">
            <div class="project">
              <img src="frontn/img/galeri2.jpeg" alt="" height="400px" width="100px" />
              <div class="overlay">
                <div>
                  <h4 class="text-white">Pemisahan Kulit dari Biji</h4>
                  <h6 class="text-white">Setelah melewati Natural Dry Process, biji kopi yang terpisah dari kulitnya kemudian di sortir untuk diproses ke tahap selanjutnya yaitu Roasting</h6>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-sm-6">
            <div class="project">
              <img src="frontn/img/galeri5.jpg" alt="" height="400px" width="100px" />
              <div class="overlay">
                <div>
                  <h4 class="text-white">Roasting</h4>
                  <h6 class="text-white">Roasting ialah proses pemanasan biji kopi dengan waktu dan suhu yang menjadi acuan hingga terjadi proses perubahan sifat kimiawi yang signifikan, yaitu hilangnya berat kering terutama gas CO2</h6>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-sm-6">
            <div class="project">
              <img src="frontn/img/galeri4.jpeg" alt="" height="400px" width="100px"/>
              <div class="overlay">
                <div>
                  <h4 class="text-white">Pengemasan</h4>
                  <h6 class="text-white">Setelah melewati proses Roasting, biji Kopi siap untuk di kemas dan di kirim ke seluruh wilayah Indonesia</h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- GALERI -->
    
     <!-- CARA MEMESAN -->
     <section id="services">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-8 mx-auto text-center">
            <h6 class="text-primary">CARA MEMESAN</h6>
            <h1>CARA MELAKUKAN PEMESANAN DI TOKO AMRANBEANS</h1>
            <p>Berikut merupakan alur pemesanan di toko AmranBeans</p>
          </div>
        </div>
        <div class="row g-4">
          <div class="col-lg-4 col-sm-6">
            <div class="service card-effect bounceInUp">
              <div class="iconbox">
                <label>
              <i class="fa-solid fa-1"></i>
</label>
              </div>
              <h5 class="mt-4 mb-2">1. Registrasi/Login Akun.</h5>
              <p>Registrasi akun terdapat pada menu Register.</p>
            </div>
          </div>
          <div class="col-lg-4 col-sm-6">
            <div class="service card-effect">
              <div class="iconbox">
              <i class="fa-solid fa-2"></i>
              </div>
              <h5 class="mt-4 mb-2">2. Pilih Produk Yang Ingin Di Beli.</h5>
              <p>Daftar Produk dapat di lihat di menu Produk.</p>
            </div>
          </div>
          <div class="col-lg-4 col-sm-6">
            <div class="service card-effect">
              <div class="iconbox">
              <i class="fa-solid fa-3"></i>
              </div>
              <h5 class="mt-4 mb-2">3. Tambahkan Ke Keranjang.</h5>
              <p>Klik icon keranjang.</p>
            </div>
          </div>
          <div class="col-lg-4 col-sm-6">
            <div class="service card-effect">
              <div class="iconbox">
              <i class="fa-solid fa-4"></i>
              </div>
              <h5 class="mt-4 mb-2">4. Bayar Sekarang.</h5>
              <p>Klik "Bayar Sekarang" untuk membayar.</p>
            </div>
          </div>
          <div class="col-lg-4 col-sm-6">
            <div class="service card-effect">
              <div class="iconbox">
              <i class="fa-solid fa-5"></i>
              </div>
              <h5 class="mt-4 mb-2">5. Pilih Ongkir.</h5>
              <p>Pilih layanan ongkir yang kamu inginkan.</p>
            </div>
          </div>
          <div class="col-lg-4 col-sm-6">
            <div class="service card-effect">
              <div class="iconbox">
              <i class="fa-solid fa-6"></i>
              </div>
              <h5 class="mt-4 mb-2">6. Pilih Metode Pembayaranmu.</h5>
              <p>Konfirmasi pembayaranmu di Live Chat !!!</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- CARA MEMESAN -->

    <!-- PRODUK -->
    <section id="produk" class="bg-light">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-8 mx-auto text-center">
            <h6 class="text-primary">PRODUK KAMI</h6>
            <h1>Biji Kopi Robusta Pagar Alam</h1>
            <p>Pesan sekarang untuk bisa merasakan kenikmatan secankir kopi berasal dari biji kopi terbaik khas Pagar Alam</p>
          </div>
        </div>
        <div class="row justify-content-evenly text-center">
                <div class="col-lg-5 mb-6">
                    <div class="card">
                        <img src="frontn/img/landingpage1.png" class="card-img-top" alt="amranbeans">
                        <div class="card-body ">
                          <h5 class="card-title">Bubuk Kopi Robusta by AmranBeans</h5>
                          <p class="card-text">Biji kopi yang telah disangrai, digiling atau ditumbuk hingga menyerupai serbuk halus, (Lansung Seduh) </p>
                          <a href="<?php echo e(route('produk')); ?>" class="btn" style="background-color: #17a2b8;">BELI SEKARANG</a>
                        </div>    
                      </div>
                </div>
                <div class="col-lg-5 mb-6">
                    <div class="card">
                        <img src="frontn/img/landingpage1.jpg" class="card-img-top" alt="amranbeans">
                        <div class="card-body ">
                          <h5 class="card-title">Biji Kopi Robusta by AmranBeans</h5>
                          <p class="card-text">Biji Kopi yang masih utuh, sangat cocok untuk usaha cafe yang mmempunyai mesin penggiling biji kopi. </p>
                          <a href="<?php echo e(route('produk')); ?>" class="btn" style="background-color: #17a2b8;">BELI SEKARANG</a>
                        </div>    
                      </div>
                </div>
    </section>
    <!-- PRODUK-->

     <!-- Start of txt.me widget code -->
  <script src="https://v3.txt.me/livechat/js/wrapper/5d08a2b6-e08a-48cd-94bb-1c65eae906eb" async></script>
  <noscript><a href="https://txt.me/reviews/5d08a2b6-e08a-48cd-94bb-1c65eae906eb" rel="nofollow">Rate AmranBeans customer support</a>, powered by <a href="https://txt.me" rel="noopener nofollow" target="_blank">txt.me</a></noscript>
  <!-- End of txt.me widget code -->

    <footer>
      <div class="footer-top">
        <div class="container">
          <div class="row gy-4">
            <div class="col-lg-4  ">
              <a href href="#home"><img class="logo" src="frontn/img/logo-dark.jpg" alt="" ></a>
            </div>
            <div class="col-lg-4">
              <h5 class="text-white">AmranBeans</h5>
              <ul class="list-unstyled">
                <li><a href="#home">Beranda</a></li>
                <li><a href="#about">Tentang Kami</a></li>
                <li><a href="#produk">Produk Kami</a></li>
              </ul>
            </div>
            <div class="col-lg-4">
              <h5 class="text-white">Kontak Kami</h5>
              <ul class="list-unstyled">
                <li><a href="https://goo.gl/maps/ynG1ccbjBxks8eGq7">ALAMAT</a></li>
                <li>EMAIL : amranbeans@gmail.com</li>
                <li><a href="https://wa.me/082114491217">HUBUNGI KAMI</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-bottom py-3">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <p class="mb-0">© 2022 copyright all right reserved | Designed with <i class="bx bx-heart text-danger"></i> by<a href="https://www.youtube.com/channel/UCYMEEnLzGGGIpQQ3Nu_sBsQ" class="text-white">AmranBeans</a></p>
            </div>
            <div class="col-md-6">
              <div class="social-icons">
                <a href="https://www.facebook.com/profile.php?viewas=100000686899395&id=100082078694523"><i class="bx bxl-facebook"></i></a>
                <a href="https://twitter.com/AmranBeans"><i class="bx bxl-twitter"></i></a>
                <a href="https://www.instagram.com/amranbeans/"><i class="bx bxl-instagram-alt"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>

    <script src="frontn/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
<?php /**PATH C:\Users\kauts\OneDrive\Desktop\e-commerce-main\resources\views/home.blade.php ENDPATH**/ ?>