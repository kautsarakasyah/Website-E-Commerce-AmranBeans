<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" href="<?php echo e(asset('frontn/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontn/css/boxicons.min.css')); ?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('frontn/css/style.css')); ?>" />
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="assets/css/my-login.css">

    <title>My Login Page</title>
  </head>

  <body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="70">
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg py-3 sticky-top navbar-light bg-light">
      <div class="container">
      <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
          <img class="logo" src="frontn/img/logo-dark.jpg" alt="" />
    </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('home')); ?>">Beranda</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- //NAVBAR -->

<body class="my-login-page">
	<section class="h-100">
		<div class="container h-100">
			<div class="row justify-content-md-center h-100">
				<div class="card-wrapper">
				<a class="brand" href="<?php echo e(route('home')); ?>">
          <img src="frontn/img/logo-dark.jpg" alt="bootstrap 4 login page" />
    </a>
					<div class="card fat">
						<div class="card-body">
							<h4 class="card-title">Register</h4>
							<form action="<?php echo e(route('postregister')); ?>" class="login-form" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <form class="user">
                            <div class="form-group">
									<label for="name">Nama</label>
									<input id="name" type="text" maxlength="30" class="form-control form-control-user" name="name" placeholder="Masukkan Nama Anda" required autofocus>
									<div class="invalid-feedback">
										Masukkan Nama Anda
									</div>
								</div>

								<div class="form-group">
									<label for="email">Alamat Email</label>
									<input id="email" type="email" maxlength="25" class="form-control form-control-user" name="email" placeholder="Masukkan Email" required>
									<div class="invalid-feedback">
										E-mail Kamu Tidak Valid
									</div>
									<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="alert alert-danger"><?php echo e($message); ?></div>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>

                                <div class="form-group">
									<label for="no_hp">Masukkan Nomor HP Anda</label>
									<input id="no_hp" type="number" maxlength="25" class="form-control form-control-user" name="no_hp" placeholder="Masukkan Nomor HP" required data-eye>
									<small id="emailHelp" class="form-text text-danger">*Maksimal 12 Digit Angka.</small>
									<div class="invalid-feedback">
										Masukkan Nomor Anda Dengan Benar
									</div>
									<?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="alert alert-danger"><?php echo e($message); ?></div>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>

								<div class="form-group">
									<label for="password">Password</label>
									<input id="password" type="password"  maxlength="12" class="form-control form-control-user" name="password" placeholder="Masukkan Password" required data-eye>
									<small id="emailHelp" class="form-text text-danger">*Maksimal 12 Karakter.</small>
									<div class="invalid-feedback">
										Password is required
									</div>
								</div>

                                <div class="form-group">
									<label for="alamat">Alamat</label>
									<input id="alamat" type="alamat" maxlength="30" class="form-control form-control-user" name="alamat" placeholder="Masukkan Alamat" required>
									<small id="emailHelp" class="form-text text-danger">*Alamat ini akan digunakan untuk pengiriman, harap masukkan alamat dengan benar.</small>
                
								</div>

                                <div class="form-group">
									<label for="provinsi">Provinsi</label>
									<input id="provinsi" type="text" maxlength="20" class="form-control form-control-user" name="provinsi" placeholder="Masukkan Provinsi" required>
								</div>

                                <div class="form-group">
									<label for="kota">Kota</label>
									<input id="kota" type="text" maxlength="20" class="form-control form-control-user" name="kota" placeholder="Masukkan Kota" required>
								</div>

                                <div class="form-group">
									<label for="kode_pos">Kode Pos</label>
									<input id="kode_pos" type="text" maxlength="7" class="form-control form-control-user" name="kode_pos" placeholder="Masukkan Kode Pos" required>
								</div>

								<div class="form-group">
									<div class="custom-checkbox custom-control">
										<input type="checkbox" name="agree" id="agree" class="custom-control-input" required="">
										<label for="agree" class="custom-control-label">I agree to the Terms and Conditions</label>
										<div class="invalid-feedback">
											You must agree with our Terms and Conditions
										</div>
									</div>
								</div>

								<div class="form-group m-0">
									<button type="submit" class="btn btn-primary btn-block">
										Register
									</button>
								</div>
								<div class="mt-4 text-center">
									Already have an account? <a href="<?php echo e(route('login')); ?>">Login</a>
								</div>
							</form>
						</div>
					</div>
					<div class="footer">
						Copyright &copy; 2022 &mdash; Amran Beans 
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<script src="js/my-login.js"></script>
	<script src="frontn/js/bootstrap.bundle.min.js"></script>

    <script>
    $(document).ready(function(){
        $('#checkbox').on('change', function(){
            $('#password').attr('type',$('#checkbox').prop('checked')==true?"text":"password"); 
        });
    });
    </script>

</body>
</html><?php /**PATH C:\Users\kauts\OneDrive\Desktop\e-commerce-main\resources\views/register.blade.php ENDPATH**/ ?>